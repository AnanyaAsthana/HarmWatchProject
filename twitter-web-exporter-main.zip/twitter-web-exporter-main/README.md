This is our twitter extension, we have to add a description
